import gmail_client, email_parser

msgs = list(gmail_client.fetch_unread_instacart_emails())
if not msgs:
    print("No unread emails found")
else:
    body = email_parser._decode_body(msgs[0]["payload"])
    # print section around "Order" to see actual format
    for i, line in enumerate(body.splitlines()):
        if "order" in line.lower() or "instacart" in line.lower():
            print(f"{i:4d}: {repr(line)}")
