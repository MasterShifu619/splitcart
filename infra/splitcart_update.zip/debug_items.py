from dotenv import load_dotenv; load_dotenv()
import gmail_client, email_parser
msgs = list(gmail_client.fetch_unread_instacart_emails())
body = email_parser._decode_body(msgs[0]["payload"])
lines = body.splitlines()
for i, l in enumerate(lines[60:160], 60):
    print(f"{i:4d}: {repr(l)}")
