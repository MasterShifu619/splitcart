import gmail_client, email_parser

msgs = list(gmail_client.fetch_unread_instacart_emails())
print(f"Found {len(msgs)} emails")
for m in msgs:
    print(email_parser.parse_instacart_email(m))
