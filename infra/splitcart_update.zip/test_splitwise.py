import splitwise_client

expense_id = splitwise_client.create_grocery_expense(
    total=91.50,
    store="Costco",
    order_date="April 29th, 2026",
    payer_id=36896689,
    instacart_order_id="19964014430480616",
)
print(f"Created expense: {expense_id}")
