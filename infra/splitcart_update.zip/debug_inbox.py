import gmail_client

svc = gmail_client._build_service()
r = svc.users().messages().list(userId='groceries.split@gmail.com', q='is:unread', maxResults=10).execute()
msgs = r.get('messages', [])
print(f'{len(msgs)} unread messages')
for m in msgs:
    full = svc.users().messages().get(
        userId='groceries.split@gmail.com', id=m['id'],
        format='metadata', metadataHeaders=['From', 'Subject']
    ).execute()
    hdrs = {h['name']: h['value'] for h in full['payload']['headers']}
    print(hdrs.get('From', '?'), '|', hdrs.get('Subject', '?'))
