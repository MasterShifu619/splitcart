from dotenv import load_dotenv; load_dotenv()
import gmail_client, email_parser
msgs = list(gmail_client.fetch_unread_instacart_emails())
if not msgs:
    print("No unread emails")
else:
    body = email_parser._decode_body(msgs[0]["payload"])
    notes = email_parser._parse_item_notes(body)
    print(notes)
