"""Usage: python debug_msg.py <message_id>"""
import sys
import gmail_client
import email_parser

msg_id = sys.argv[1]
svc = gmail_client._build_service()
msg = svc.users().messages().get(
    userId=gmail_client.SHARED_INBOX, id=msg_id, format="full"
).execute()

body = email_parser._decode_body(msg["payload"])
print("=== FULL BODY ===")
print(body)
